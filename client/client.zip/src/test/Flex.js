import React from "react";

function Flex() {
  return <div className="flex">
    <div className=""> box 1 iordfg x bux d xxbb xbdzg b zj h hj</div>
    <div className=""> box 2 szo efsiug ddrs gris zz ilz fix gzguiz</div>
    <div className="">box 3 ff szfgihksziohzx vjxbzz ghgug haga</div>
    <div className=""> box 4 zx ghdi hugodjgdhg  zhnzghgill drgd</div>
    <div className=""> box 5fgcb xu vfxu gheisug axg  jei usghsebo v</div>
    <div className="">box 6 vfzdzj     b kh zbzhbzh hh ghhgsr</div>
    <div className="">box  xbdoxdghhOJI GJAGERG JJORG JBD XD FBISJ fghjdfg7</div>
  </div>;
}

export default Flex;
