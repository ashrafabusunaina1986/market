import React from "react";
import Parent from "./callback/Parent";

function Test() {
  return <div>
    <Parent/>
  </div>;
}

export default Test;
