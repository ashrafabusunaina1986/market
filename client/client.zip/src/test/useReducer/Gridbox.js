import React from "react";

function Gridbox() {
  return <div className="form-post g">
    <div className="item-1 grid-d"> box 1</div>
    <div className="item-2 grid-d"> box 2</div>
    <div className="item-3 grid-d">box 3</div>
    <div className="item-5 grid-d"> box 4</div>
    <div className="item-6 grid-d"> box 5</div>
    <div className="item-7 grid-d">box 6</div>
    <div className="item-4 grid-d">box 7</div>
  </div>;
}

export default Gridbox;
